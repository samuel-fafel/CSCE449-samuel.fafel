#include <math.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
  // Read input from inA.txt
  int rowsA, colsA;
  FILE *inA = fopen("inA.txt", "r");
  if (inA == NULL) {
    printf("Error Opening inA.txt\n");
    exit(1);
  }
  fscanf(inA, "%d %d", &rowsA, &colsA);
  float **A = malloc(rowsA * sizeof(float *));
  for (int i = 0; i < rowsA; i++) {
    A[i] = malloc(colsA * sizeof(float));
    for (int j = 0; j < colsA; j++) {
      fscanf(inA, "%f", &A[i][j]);
    }
  }
  fclose(inA);

  // Read input Matrix B from inB.txt
  int rowsB, colsB;
  FILE *inB = fopen("inB.txt", "r");
  if (inB == NULL) {
    printf("Error Opening inB.txt\n");
    exit(1);
  }
  fscanf(inB, "%d %d", &rowsB, &colsB);
  float **B = malloc(rowsB * sizeof(float *));
  for (int i = 0; i < rowsB; i++) {
    B[i] = malloc(colsB * sizeof(float));
    for (int j = 0; j < colsB; j++) {
      fscanf(inB, "%f", &B[i][j]);
    }
  }
  fclose(inB);

  if (rowsA != rowsB || colsA != colsB) {
    printf("Dimension Mismatch: Cannot Add Matrix Transposes.");
    exit(1);
  }

  // Allocate memory for transpose of Matrix A
  float **AT = malloc(colsA * sizeof(float *));
  for (int i = 0; i < colsA; i++) {
    AT[i] = malloc(rowsA * sizeof(float));
  }

  // Calculate transpose of Matrix A
  for (int i = 0; i < rowsA; i++) {
    for (int j = 0; j < colsA; j++) {
      AT[j][i] = A[i][j];
    }
  }

  // Allocate memory for transpose of Matrix B
  float **BT = malloc(colsB * sizeof(float *));
  for (int i = 0; i < colsB; i++) {
    BT[i] = malloc(rowsB * sizeof(float));
  }

  // Calculate transpose of Matrix B
  for (int i = 0; i < rowsB; i++) {
    for (int j = 0; j < colsB; j++) {
      BT[j][i] = B[i][j];
    }
  }

  // Allocate memory for output Matrix C
  float **C = malloc(colsA * sizeof(float *));
  for (int i = 0; i < colsA; i++) {
    C[i] = malloc(rowsA * sizeof(float));
  }

  // Add AT and BT to form Matrix C
  for (int i = 0; i < colsA; i++) {
    for (int j = 0; j < rowsA; j++) {
      C[i][j] = AT[i][j] + BT[i][j];
    }
  }

  // Write output Matrix C to outC.txt
  FILE *outC = fopen("outC.txt", "w");
  fprintf(outC, "%d %d\n", colsA, rowsA);
  for (int i = 0; i < colsA; i++) {
    for (int j = 0; j < rowsA; j++) {
      fprintf(outC, "%f ", C[i][j]);
    }
    fprintf(outC, "");
  }
  fclose(outC);
  printf("Writing Finished\n");

  // Free memory
  for (int i = 0; i < rowsA; i++) {
    free(A[i]);
  }
  free(A);

  for (int i = 0; i < colsA; i++) {
    free(AT[i]);
    free(C[i]);
  }
  free(AT);
  free(C);

  for (int i = 0; i < rowsB; i++) {
    free(B[i]);
  }
  free(B);

  for (int i = 0; i < colsB; i++) {
    free(BT[i]);
  }
  free(BT);

  printf("Memory Cleared\n");

  return 0;
}
