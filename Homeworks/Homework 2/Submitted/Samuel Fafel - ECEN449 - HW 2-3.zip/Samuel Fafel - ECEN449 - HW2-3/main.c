#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { // Student Struct
  char firstname[50];
  char lastname[50];
  int section;
  int uin;
} Student;

// Global variables
Student students[9];
int num_students = 0;
int available_seats_per_section[3] = {3, 3, 3};
int all_sections[3] = {501, 502, 503};

// 'Add' Functionality
void add_student() {
  char firstname[50];
  char lastname[50];
  int section, uin;
  printf("Enter Student Name, UIN, and Section (501, 502, 503): ");
  scanf("%s %s %d %d", firstname, lastname, &uin, &section);
  if (section < 501 || section > 503) {
    printf("Invalid section. Please try again.\n");
    return;
  }
  if (available_seats_per_section[section - 501] == 0) {
    printf("Section %d is full. Available sections: ", section);
    for (int i = 0; i < 3; i++) {
      if (available_seats_per_section[i] > 0) {
        printf("%i, ", all_sections[i]);
      }
    }
    printf("\n");
    return;
  }

  Student s = {0}; // Create Student
  strcpy(s.firstname, firstname);
  strcpy(s.lastname, lastname);
  s.section = section;
  s.uin = uin;
  students[num_students++] = s; // Add Student 
  available_seats_per_section[section - 501]--; // Decrement Seats in Section
  printf("Added %s %s to Section %d.\n", firstname, lastname, section);
}

// 'Remove' Functionality
void remove_student() {
  char firstname[50];
  char lastname[50];
  int section;
  printf("Enter Student Name and Section (501, 502, 503): ");
  scanf("%s %s %d", firstname, lastname, &section);
  if (section < 501 || section > 503) {
    printf("Invalid section. Please try again.\n");
    return;
  }
  for (int i = 0; i < num_students; i++) {
    if (strcmp(firstname, students[i].firstname) == 0 &&
        students[i].section == section) {
      // Remove the student and shift all subsequent
      // elements one position to the left
      for (int j = i; j < num_students - 1; j++) {
        students[j] = students[j + 1];
      }
      num_students--;
      available_seats_per_section[section - 501]++;
      printf("Removed %s %s from Section %d.\n", firstname, lastname, section);
      return;
    }
  }
  printf("No student named %s %s found in Section %d.\n", firstname, lastname, section);
}

// 'Create Roster' Functionality
void create_roster() {
  int total_seats = 9;
  int occupied_seats = num_students;
  int remaining_seats = total_seats - occupied_seats;
  printf("Total number of seats: %d\n", total_seats);
  printf("Number of seats occupied: %d\n", occupied_seats);
  printf("Number of seats remaining: %d\n", remaining_seats);
  for (int section = 501; section <= 503; section++) {
    printf("Section %d:\n", section);
    int num_students_in_section = 0;
    for (int i = 0; i < num_students; i++) {
      if (students[i].section == section) {
        num_students_in_section++;
      }
    }
    printf("Number of students enrolled: %d\n", num_students_in_section);
    if (num_students_in_section == 0) {
      printf("No students enrolled in this section.\n");
    } else {
      Student section_students[num_students_in_section];
      int k = 0;
      for (int i = 0; i < num_students; i++) {
        if (students[i].section == section) {
          section_students[k] = students[i];
          k++;
        }
      }
      // Sort the students in alphabetical order by name
      for (int i = 0; i < num_students_in_section - 1; i++) {
        for (int j = i + 1; j < num_students_in_section; j++) {
          if (strcmp(section_students[i].firstname,
                     section_students[j].firstname) > 0) {
            Student temp = section_students[i];
            section_students[i] = section_students[j];
            section_students[j] = temp;
          }
        }
      }
      // Write the student names and UINs to a file named after the section
      char filename[8];
      sprintf(filename, "%d.txt", section);
      FILE *file = fopen(filename, "w");
      for (int i = 0; i < num_students_in_section; i++) {
        fprintf(file, "%s %s %d\n", section_students[i].firstname,
                section_students[i].lastname, section_students[i].uin);
        printf("%s %s - UIN %d\n", section_students[i].firstname,
               section_students[i].lastname, section_students[i].uin);
      }
      fclose(file);
    }
  }
}

int main() {
  int choice = 0;
  while (choice != 4) {
    printf("\n----- Menu -----\n");
    printf("1: Add\n");
    printf("2: Remove\n");
    printf("3: Create Roster\n");
    printf("----------------\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);
    switch (choice) {
    case 1:
      add_student();
      break;
    case 2:
      remove_student();
      break;
    case 3:
      create_roster();
      break;
    default:
      printf("Exiting...\n");
      break;
    }
  }
  return 0;
}